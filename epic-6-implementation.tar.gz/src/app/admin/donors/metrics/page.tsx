'use client'

import { DonorMetricsDashboard } from '@/components/dashboards/crisis/DonorMetricsDashboard'

export default function DonorMetricsPage() {
  return <DonorMetricsDashboard />
}